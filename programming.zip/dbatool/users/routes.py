from crypt import methods
from flask import Blueprint

users = Blueprint('users', __name__)

@users.route("/login", methods=['POST'])
def login:
    print ('Hello')