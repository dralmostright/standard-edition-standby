DECLARE
stmt VARCHAR2(31700);
currSeq NUMBER;
currUserId NUMBER;
errorMessage VARCHAR2(32767);
objstatus VARCHAR2(100);
errorVal VARCHAR2(10);

real_ora_dict_obj_name VARCHAR2(4000);
real_ora_dict_obj_owner VARCHAR2(400);
real_ora_dict_obj_type VARCHAR2(130);

otype VARCHAR2(400);
disallowDDL NUMBER;
baseTabCount NUMBER := 0;
indexUnique VARCHAR2(130);
moduleNameInfo VARCHAR2(400);
oldModuleNameInfo VARCHAR2(400);
oldActionInfo VARCHAR2(400);


binObject NUMBER;



dbRole VARCHAR2(130);
dbOpenMode VARCHAR2(130);

seqCache NUMBER;
seqIncrementBy NUMBER;
pieceStmt VARCHAR2(31700);
outMessage VARCHAR2(32767);
toIgnore VARCHAR2(130);
journalId NUMBER;
journalIndexOwner VARCHAR2(400);
journalType VARCHAR2(130);
objectTemporary varchar2(130);
objectGenerated varchar2(130);
objectSecondary varchar2(130);
objectType varchar2(130);
userCancelSimulate EXCEPTION;
userCancelNestedSimulate EXCEPTION;
PRAGMA EXCEPTION_INIT (userCancelSimulate, -1013);
PRAGMA EXCEPTION_INIT (userCancelNestedSimulate, -1017);
isTypeTable varchar2(130);
isNestedTable varchar2(130);
isValidTimeTable varchar2(130);
isIdentityColTable varchar2(130);
ntype NUMBER;
BEGIN

    -- IMPORTANT: this check must happen BEFORE ANY PROCESSING
    -- perform check for role of this database
    -- if database is not PRIMARY/LOGICAL STANDBY,  and if it's not READ WRITE
    -- then this trigger cannot (and should not) operate
    -- In case of not wanting trigger on LOGICAL STANDBY (or with READ WRITE),
    -- ddl_disable script can be used on standby to disable the trigger
    BEGIN
              IF "GGATECRS".DDLReplication.dbQueried IS NULL THEN
		SELECT database_role, open_mode
		INTO dbRole, dbOpenMode
		FROM v$database;
                "GGATECRS".DDLReplication.dbQueried := TRUE;
              END IF;

		IF NOT (
			(dbRole = 'PRIMARY' OR dbRole = 'LOGICAL STANDBY')
			AND dbOpenMode = 'READ WRITE'
			)
			THEN
			-- do not write any trace even though it should work as this is standby
                        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

			RETURN; -- do not use trigger if not read/write and primary/logical_standby
		END IF;
	EXCEPTION
        WHEN OTHERS THEN	-- this should never happen
        IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
            RAISE;
        END IF;
        "GGATECRS" .trace_put_line ('DDL', 'Error in obtaining dbrole, open mode, error ['
                                || SQLERRM || ']');
		raise_application_error (-20782,
                                         "GGATECRS" .DDLReplication.triggerErrorMessage || ':' || SQLERRM);

	END;
    -- END OF IMPORTANT CHECK


    -- the following MUST happen after checking for role of the database
    -- but BEFORE anything else. Here we check if DDL is recyclebin. Recyclebin
    -- DDL can happen as 'interrupting' original DDL and shares the same
    -- memory, thus entirely messing up RDBMS trigger processing and potentially
    -- causing db to hang.
    -- set tracing from setup table

    "GGATECRS" .DDLReplication.setTracing ();


    -- retrieve first 4K of DDL statement.
    -- we only use the DDL for history table that doesn't require whole DDL text.
    IF "GGATECRS" .DDLReplication.getDDLText (stmt) = 0 THEN
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);
        RETURN;
    END IF;

    IF "GGATECRS" .DDLReplication.isRecycle(stmt) = 1 THEN
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', 'DDL ignored, it is recycle bin DDL, text [' || stmt || ']');
        END IF;
        IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
            dbms_session.set_sql_trace(false);
        END IF;
        -- just ignore recyclebin objects
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

        RETURN;
    END IF;

    -- we now issue space management DDLs for some OGG objects,
    -- such as enabling row movement.  All such DDLs are to be ignored.
    -- This will also ignore any user erroneous statements, while
    -- maintaining log about it.
    IF (upper(ora_dict_obj_name) = upper ('GGS_MARKER') OR
        upper(ora_dict_obj_name) = upper ('GGS_MARKER_SEQ') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_TRIGGER_BEFORE') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_SEQ') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_HIST') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_HIST_ALT') OR
        upper(ora_dict_obj_name) = upper ('GGS_SETUP')) AND

        upper(ora_dict_obj_owner) = upper ('GGATECRS') AND

        (upper(ora_sysevent) = upper ('ALTER'))

        THEN
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', 'DDL ignored, it is alter GGS object DDL, text [' || stmt || ']');
        END IF;
        IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
            dbms_session.set_sql_trace(false);
        END IF;
        -- just ignore recyclebin objects
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);
        RETURN;

    END IF;

    -- we can safely ignore tables like ORA_TEMP_#_DS_###### which are used by the system when gathering statistics
    IF (ora_dict_obj_owner = 'SYS' AND upper(ora_dict_obj_name) like 'ORA\_TEMP\_%\_DS\_%' escape '\') THEN
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', 'DDL ignored, it relates to a temporary table used for statistics, text [' || stmt || ']');
        END IF;
        IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
            dbms_session.set_sql_trace(false);
        END IF;
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);
        RETURN;
    END IF;

    disallowDDL := 0; -- DDL is normally allowed
    toIgnore := 'NO'; -- do not ignore DDL by default

    -- used to delete marker entry in cancel error
    "GGATECRS" .DDLReplication.currentMarkerSeq := NULL;

    -- support for exceptions testing
    IF 'FALSE' = 'TRUE' THEN
        SELECT VALUE
        INTO errorVal
        FROM "GGATECRS" ."GGS_SETUP"
        WHERE property = ',?!%*$#';
    END IF;

    -- get DDL history sequence, initialize object Id
    SELECT "GGATECRS" ."GGS_DDL_SEQ" .NEXTVAL INTO "GGATECRS" .DDLReplication.currentDDLSeq FROM dual;
    "GGATECRS" .DDLReplication.currentObjectId := NULL;

    IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
        "GGATECRS" .trace_put_line ('DDL', '************************* Start of log for DDL sequence ['
                                || to_char ("GGATECRS" .DDLReplication.currentDDLSeq) || '], v[ ' ||
                                'OGGCORE_19.1.0.0.0_PLATFORMS_191017.1054' || '] trace level [' ||
                                "GGATECRS" .DDLReplication.trace_level || '], owner schema of DDL package [GGATECRS], objtype ['
                                || ora_dict_obj_type || '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || ']');
    END IF;

	IF "GGATECRS" .filterDDL (
        stmt,
		ora_dict_obj_owner,
		ora_dict_obj_name,
		ora_dict_obj_type,
		ora_sysevent) = 'EXCLUDE' THEN
		IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', 'DDL ignored because filterDDL returned EXCLUDE');
        END IF;
                "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

		RETURN;
	END IF;

     -- check if we want this statement at all before going any further
     -- this way we avoid some large DDL that we wouldn't want anyway
     IF ora_dict_obj_type <> 'TABLESPACE' AND
        -- Keep this list in sync with results returned by this query:
        -- select name from system.logstdby$skip_support where action = 0 order by name;
        (ora_dict_obj_owner = 'ANONYMOUS' OR -- HTTP access to XDB
         ora_dict_obj_owner = 'APPQOSSYS' OR -- QOS system user
         ora_dict_obj_owner = 'AUDSYS' OR -- audit super user
         ora_dict_obj_owner = 'BI' OR -- Business Intelligence
         ora_dict_obj_owner = 'CTXSYS' OR -- Text
         ora_dict_obj_owner = 'DBSNMP' OR -- SNMP agent for OEM
         ora_dict_obj_owner = 'DIP' OR -- Directory Integration Platform
         ora_dict_obj_owner = 'DMSYS' OR -- Data Mining
         ora_dict_obj_owner = 'DVF' OR -- Database Vault
         ora_dict_obj_owner = 'DVSYS' OR -- Database Vault
         ora_dict_obj_owner = 'EXDSYS' OR -- External ODCI System User
         ora_dict_obj_owner = 'EXFSYS' OR -- Expression Filter
         ora_dict_obj_owner = 'GSMADMIN_INTERNAL' OR -- Global Service Manager
         ora_dict_obj_owner = 'GSMCATUSER' OR -- Global Service Manager
         ora_dict_obj_owner = 'GSMUSER' OR -- Global Service Manager
         ora_dict_obj_owner = 'LBACSYS' OR -- Label Security
         ora_dict_obj_owner = 'MDSYS' OR -- Spatial
         ora_dict_obj_owner = 'SPATIAL_CSW_ADMIN' OR -- Spatial Catalog Services for Web
         ora_dict_obj_owner = 'SPATIAL_CSW_ADMIN_USR' OR -- Spatial
         ora_dict_obj_owner = 'SPATIAL_WFS_ADMIN' OR -- Spatial Web Feature Service
         ora_dict_obj_owner = 'SPATIAL_WFS_ADMIN_USR' OR -- Spatial
         ora_dict_obj_owner = 'MGMT_VIEW' OR -- OEM Database Control
         ora_dict_obj_owner = 'MTSSYS' OR -- MS Transaction Server
         ora_dict_obj_owner = 'ODM' OR -- Data Mining
         ora_dict_obj_owner = 'ODM_MTR' OR -- Data Mining Repository
         ora_dict_obj_owner = 'OJVMSYS' OR -- Java Policy SRO Schema
         ora_dict_obj_owner = 'OLAPSYS' OR -- OLAP catalogs
         ora_dict_obj_owner = 'ORACLE_OCM' OR -- Oracle Configuration Manager User
         ora_dict_obj_owner = 'ORDDATA' OR -- Intermedia
         ora_dict_obj_owner = 'ORDPLUGINS' OR -- Intermedia
         ora_dict_obj_owner = 'ORDSYS' OR -- Intermedia
         ora_dict_obj_owner = 'OUTLN' OR -- Outlines (Plan Stability)
         ora_dict_obj_owner = 'SI_INFORMTN_SCHEMA' OR -- SQL/MM Still Image
         ora_dict_obj_owner = 'SYS' OR
         ora_dict_obj_owner = 'SYSBACKUP' OR
         ora_dict_obj_owner = 'SYSDG' OR
         ora_dict_obj_owner = 'SYSKM' OR
         ora_dict_obj_owner = 'SYSMAN' OR -- Adminstrator OEM
         ora_dict_obj_owner = 'SYSTEM' OR
         ora_dict_obj_owner = 'TSMSYS' OR -- Transparent Session Migration
         ora_dict_obj_owner = 'WKPROXY' OR -- Ultrasearch
         ora_dict_obj_owner = 'WKSYS' OR -- Ultrasearch
         ora_dict_obj_owner = 'WK_TEST' OR
         ora_dict_obj_owner = 'WMSYS' OR -- Workspace Manager
         ora_dict_obj_owner = 'XDB' OR -- XML DB
         ora_dict_obj_owner = 'XS$NULL' OR
         ora_dict_obj_owner = 'XTISYS' OR -- Time Index
         -- Below are schemas considered special to GG not returned by above query.
         ora_dict_obj_owner = 'AURORA$JIS$UTILITY$' OR -- JSERV
         ora_dict_obj_owner = 'AURORA$ORB$UNAUTHENTICATED' OR -- JSERV
         ora_dict_obj_owner = 'DSSYS' OR -- Dynamic Services Secured Web Service
         ora_dict_obj_owner = 'OSE$HTTP$ADMIN' OR -- JSERV
         ora_dict_obj_owner = 'PERFSTAT' OR -- STATSPACK
         (ora_dict_obj_owner = 'PUBLIC'  AND ora_dict_obj_type <> 'SYNONYM') OR
         ora_dict_obj_owner = 'REPADMIN' OR
         ora_dict_obj_owner = 'TRACESVR' -- Trace server for OEM
        )
        THEN
            IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
                "GGATECRS" .trace_put_line ('DDL', 'Object [' || ora_dict_obj_owner || '.' ||
                                    ora_dict_obj_name || '] is ignored because object name is Oracle-reserved system name');
            END IF;
            toIgnore := 'YES';
    END IF;

    IF upper(substr (ora_dict_obj_name, 1, 5)) = 'MLOG$' OR upper(substr (ora_dict_obj_name, 1, 5)) = 'RUPD$'
    THEN
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', 'Ignoring MLOG$ Object [' || ora_dict_obj_owner || '.' ||
                            ora_dict_obj_name || ' as it is temporary');
        END IF;
        toIgnore := 'YES';
    END IF;

    IF upper(substr (ora_dict_obj_name, 1, 6)) = 'OGGQT$' OR upper(substr (ora_dict_obj_name, 1, 3)) = 'AQ$'
       OR upper(substr (ora_dict_obj_name, 1, 4)) = 'OGG$'
    THEN
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', 'Ignoring Queue related Object [' || ora_dict_obj_owner || '.' ||
                            ora_dict_obj_name || ' as it is for internal use');
        END IF;
        toIgnore := 'YES';
    END IF;

    IF (upper(ora_dict_obj_name) = upper ('GGS_MARKER') OR
        upper(ora_dict_obj_name) = upper ('GGS_MARKER_SEQ') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_TRIGGER_BEFORE') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_SEQ') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_HIST') OR
        upper(ora_dict_obj_name) = upper ('GGS_DDL_HIST_ALT') OR
        upper(ora_dict_obj_name) = upper ('GGS_SETUP')) AND

        upper(ora_dict_obj_owner) = upper ('GGATECRS') AND

        (upper(ora_sysevent) = upper ('DROP') OR
         upper(ora_sysevent) = upper ('RENAME'))

        THEN
        disallowDDL := 1;
        raise_application_error (-20782,
                                 'Cannot DROP object used in Oracle GoldenGate replication while trigger is enabled. ' ||
                                 'Consult Oracle GoldenGate documentation and/or call Oracle GoldenGate Technical Support if you wish to do so.');
    END IF;


    -- check if this is domain index DDL (related to it)
    IF ( ora_dict_obj_type = 'TABLE' OR ora_dict_obj_type = 'INDEX') AND
        (
        (substr(ora_dict_obj_name, 1, 3) = 'DR$' AND
            (
                substr (ora_dict_obj_name, length (ora_dict_obj_name) - 1, 1) = '$'
            )
        )
        OR
        (
           -- ignore objects that start with SYS_C, much like we ignore DR$, BIN$ etc.
           substr (ora_dict_obj_name, 1, 5) = 'SYS_C'
        )
        )
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1', 'Object is secondary for INDEX DOMAIN creation, ignored, objtype [' || ora_dict_obj_type ||
                '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    -- check for and ignore internal space management tables.
    -- Table will look something like CMP3$78931 when rdbms >= 12.1
    -- Table will look something like DBMS_TABCOMP_TEMP_* when rdbms < 12.1
    IF  ora_dict_obj_type = 'TABLE' AND
        (substr (ora_dict_obj_name, 1, 18) = 'DBMS_TABCOMP_TEMP_' OR
         (substr (ora_dict_obj_name, 1, 3) = 'CMP' AND
          instr  (ora_dict_obj_name, '$') > 0))
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1',
                'Ignoring internal space management table [' ||
                ora_dict_obj_type || '] name [' || ora_dict_obj_owner || '.' ||
                ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    -- check for and ignore Spatial temporary tables used during Spatial index creation.
    -- Table will look something like M2_12AB$$
    IF  length (ora_dict_obj_name) > 5 AND
        substr (ora_dict_obj_name, length (ora_dict_obj_name) - 1, 2) = '$$' AND
        instr  (ora_dict_obj_name, '_') > 0 AND
        substr (ora_dict_obj_name, 1, 1) = 'M'
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1',
                'Ignoring temporary Spatial table used during Spatial index creation [' ||
                ora_dict_obj_type || '] name [' || ora_dict_obj_owner || '.' ||
                ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    -- check for and ignore Spatial temporary tables/sequences used during Spatial index creation.
    -- Table will look something like MDRT_1233AB$
    IF  length (ora_dict_obj_name) > 5 AND
        substr (ora_dict_obj_name, length (ora_dict_obj_name) , 1) = '$' AND
        instr  (ora_dict_obj_name, '_') > 0 AND
        substr (ora_dict_obj_name, 1, 3) = 'MDR'
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1',
                'Ignoring temporary Spatial table used during Spatial index creation [' ||
                ora_dict_obj_type || '] name [' || ora_dict_obj_owner || '.' ||
                ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    -- check for and ignore Spatial extended stats tables created during dbms_stats
    -- Tables will look something like MDXT_1432D$_BKTS or MDXT_1432D$_MBR or MDXT_%OBJID%$
    IF  length (ora_dict_obj_name) > 5 AND
        substr (ora_dict_obj_name, 1, 5) = 'MDXT_' AND
	instr  (ora_dict_obj_name, '$') > 0
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1',
                'Ignoring Spatial extended stats tables [' ||
                ora_dict_obj_type || '] name [' || ora_dict_obj_owner || '.' ||
                ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    IF (ora_dict_obj_type = 'TABLE' AND
        (substr(ora_dict_obj_name, 1, 16) = 'SYS_IMPORT_TABLE' OR
            substr(ora_dict_obj_name, 1, 3) = 'ET$' OR
            substr(ora_dict_obj_name, 1, 4) = 'WRR$'))
       OR (ora_dict_obj_type = 'INDEX' AND
        substr(ora_dict_obj_name, 1, 10) = 'SYS_MTABLE')
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1', 'Object is secondary for Batch Workload ignored, objtype [' || ora_dict_obj_type ||
                '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    IF ora_dict_obj_type = 'TABLE' AND
        substr(ora_dict_obj_name, 1, 12) = 'SYS_JOURNAL_'
    THEN
        BEGIN
        journalId := to_number (substr(ora_dict_obj_name, 13));
        SELECT owner, object_type
        INTO
            journalIndexOwner, journalType
        FROM sys.dba_objects
        WHERE object_id = journalId;
        IF journalIndexOwner = ora_dict_obj_owner AND journalType = 'INDEX' THEN
            -- if SYS_JOURNAL_xxxxx has xxxxx to be existing object of type INDEX, this is online rebuild index, which we ignore
            toIgnore := 'YES';
        END IF;
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1', 'Object is secondary for INDEX DOMAIN creation, ignored, objtype [' || ora_dict_obj_type ||
                '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
        EXCEPTION
           WHEN OTHERS THEN
            IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                RAISE;
            END IF;
            NULL; -- never mind, this isn't oracle journal table for rebuilding online index
        END;
    END IF;

    -- Ignore Oracle 9i internal 'create/drop summary' when the user creates or drops of meteriazied view that has a SUM column.
    IF ora_dict_obj_type = 'SUMMARY'
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1', 'Object is Oracle internal create summary for materialized views, ignored, objtype [' || ora_dict_obj_type ||
                '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

   IF ora_dict_obj_type = 'DATABASE LINK'
    THEN
        toIgnore := 'YES';
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDLTRACE1', 'Object is Database Link, ignored, objtype [' || ora_dict_obj_type ||
                '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || '], error [' || to_char( SQLCODE) || ']');
        END IF;
    END IF;

    IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [1.0], objtype [' || ora_dict_obj_type ||
            '] name [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || ']');
    END IF;

    IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [1], original operation = [' ||
                                    stmt || '], DDL seqno = [' || to_char ("GGATECRS" .DDLReplication.currentDDLSeq) || ']' );
    END IF;

    IF stmt = '' OR stmt IS NULL THEN
		-- oracle sometimes creates a follow-up DDL without statement and session user
		-- this statement is related to previous one and is not a user statement, so is ignored
		"GGATECRS" .trace_put_line ('DDLTRACE1', 'DDL appears empty, ignoring');
        IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
            dbms_session.set_sql_trace(false);
        END IF;
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

        RETURN;
    END IF;

    "GGATECRS" .DDLReplication.getVersion();

    IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: proceeding with processing');
    END IF;

    -- get user id and object id as of this DDL
    -- we're looking at TABLE and SEQUENCE (or related! such as CREATE UNIQUE INDEX) for object versioning
    -- otherwise there is none
    -- object id is always that of TABLE or SEQUENCE


    -- get user id of object owner
    BEGIN
        IF "GGATECRS" .DDLReplication.ddlObjUserId = -1 THEN
        SELECT user# INTO currUserId FROM sys.user$ WHERE name = ora_dict_obj_owner;
        ELSE
          currUserId := "GGATECRS" .DDLReplication.ddlObjUserId ;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            currUserId :=  - 1;
        WHEN OTHERS THEN
            IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                RAISE;
            END IF;
            currUserId :=  - 1;
    END;


    "GGATECRS" .DDLReplication.currentMasterOwner := '';
    "GGATECRS" .DDLReplication.currentMasterName := '';
    "GGATECRS" .DDLReplication.currentRowid := '';
    real_ora_dict_obj_name := ora_dict_obj_name;
    real_ora_dict_obj_owner := ora_dict_obj_owner;
    real_ora_dict_obj_type := ora_dict_obj_type;

    -- Oracle puts 0 sometimes in these particular predefined variables, at the end, so REPLACE first
    -- the extract history record query crashes as DDL data seems incomplete
    real_ora_dict_obj_name := REPLACE (real_ora_dict_obj_name, chr(0), ' ');
    real_ora_dict_obj_name := rtrim (real_ora_dict_obj_name, ' ');
    real_ora_dict_obj_owner := REPLACE (real_ora_dict_obj_owner, chr(0), ' ');
    real_ora_dict_obj_owner := rtrim (real_ora_dict_obj_owner, ' ');
    real_ora_dict_obj_type := REPLACE (real_ora_dict_obj_type, chr(0), ' ');
    real_ora_dict_obj_type := rtrim (real_ora_dict_obj_type, ' ');


    /*

    the purpose of following code is to obtain this information:

    object id of table or sequence affected

    if object is not a table, then we need to get the name and owner
    of table affected (base table), this is currentMasterOwner/currentMasterName

    If operation is CREATE, then no metadata is known here (b/c it's before trigger).

    */

    -- MATERIALIZE VIEW: we're interested in table part of it!
    -- note: this must happen before checking for TABLE!
    IF real_ora_dict_obj_type = 'MATERIALIZED VIEW' OR
        real_ora_dict_obj_type = 'SNAPSHOT' THEN
        real_ora_dict_obj_type := 'TABLE';
    END IF;

    IF ora_sysevent <> 'CREATE'  or ora_dict_obj_type <> 'TABLE'
    THEN
      "GGATECRS" .DDLReplication.getDDLObjInfo(real_ora_dict_obj_type, ora_sysevent,
                    ora_dict_obj_owner, ora_dict_obj_name );
    END IF;
    -- Try to find base object name/owner
    -- If this is CREATE, there is no need to do it, since it doesn't exist yet
    -- In case of CREATE, extract will perform resolution of base object owner

    -- first try easier case when it's not CREATE
    IF NOT ora_sysevent = 'CREATE' THEN
        IF real_ora_dict_obj_type = 'INDEX' THEN
            BEGIN
                SELECT i.bo#, u.name, o.name , o.owner#
                INTO "GGATECRS" .DDLReplication.ddlBaseObjNum,
                     "GGATECRS" .DDLReplication.currentMasterOwner,
                     "GGATECRS" .DDLReplication.currentMasterName,
                     "GGATECRS" .DDLReplication.ddlBaseObjUserId
                FROM sys.ind$ i, sys.obj$ o, sys.user$ u
                WHERE i.obj# =  "GGATECRS" .DDLReplication.ddlObjNum and
                      o.obj# = i.bo# and u.user# = o.owner#;

                select o.type# into otype FROM sys.obj$ o
                where o.obj# = "GGATECRS" .DDLReplication.ddlBaseObjNum;

                "GGATECRS" .DDLReplication.getObjTypeName(otype, otype);

                real_ora_dict_obj_owner := "GGATECRS" .DDLReplication.currentMasterOwner;
                real_ora_dict_obj_name := "GGATECRS" .DDLReplication.currentMasterName;
                IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
					"GGATECRS" .trace_put_line ('DDLTRACE1', 'Non-CREATE INDEX, master object [' || real_ora_dict_obj_owner ||
						'.' || real_ora_dict_obj_name || ']');
		END IF;
                "GGATECRS" .DDLReplication.currentObjectId :=
                     "GGATECRS" .DDLReplication.ddlBaseObjNum;

                IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                    "GGATECRS" .trace_put_line ('DDLTRACE1', 'Non-CREATE INDEX, parent object id: ' || "GGATECRS" .DDLReplication.currentObjectId);
                END IF;

            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    "GGATECRS" .DDLReplication.currentMasterOwner := '';
                    "GGATECRS" .DDLReplication.currentMasterName := '';
                WHEN OTHERS THEN
                    IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                        RAISE;
                    END IF;
                    "GGATECRS" .DDLReplication.currentMasterOwner := '';
                    "GGATECRS" .DDLReplication.currentMasterName := '';
            END;
        END IF;
        IF real_ora_dict_obj_type = 'TRIGGER' THEN
            BEGIN
                SELECT tr.baseobject, u.name, o.name
                INTO "GGATECRS" .DDLReplication.ddlBaseObjNum,
                     "GGATECRS" .DDLReplication.currentMasterOwner,
                     "GGATECRS" .DDLReplication.currentMasterName
                FROM sys.trigger$ tr, sys.obj$ o, sys.user$ u
                WHERE tr.obj# =  "GGATECRS" .DDLReplication.ddlObjNum and
                      o.obj# = tr.baseobject and u.user# = o.owner#;
                IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                    "GGATECRS" .trace_put_line ('DDLTRACE1', 'Non-CREATE TRIGGER, parent object id: ' || "GGATECRS" .DDLReplication.ddlBaseObjNum);
                END IF;

                -- do not set real_ora names b/c trigger changes don't affect GG object resolution
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    "GGATECRS" .DDLReplication.currentMasterOwner := '';
                    "GGATECRS" .DDLReplication.currentMasterName := '';
                WHEN OTHERS THEN
                    IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                        RAISE;
                    END IF;
                    "GGATECRS" .DDLReplication.currentMasterOwner := '';
                    "GGATECRS" .DDLReplication.currentMasterName := '';
            END;
        END IF;
    END IF;
    IF real_ora_dict_obj_type = 'SEQUENCE' THEN
        BEGIN
            -- get sequence CACHE/INCREMENTBY information as well as objectid
            -- which will be used in conjuction with ROWID to resolve sequence
            seqIncrementBy := 0;
            seqCache := 0;
            SELECT o.obj#, s.increment$, s.cache
            INTO "GGATECRS" .DDLReplication.currentObjectId, seqIncrementBy, seqCache
            FROM sys.obj$ o, sys.seq$ s
            WHERE o.obj# = "GGATECRS" .DDLReplication.ddlObjNum AND
                  s.obj# = o.obj#;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                "GGATECRS" .DDLReplication.currentObjectId := NULL;
            WHEN OTHERS THEN
                IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                    RAISE;
                END IF;
                "GGATECRS" .DDLReplication.currentObjectId := NULL;
        END;
        -- now find rowid of this sequence
        -- in SYS.SEQ$ table (which is what we get from redo log)
        BEGIN
            SELECT ROWID
            INTO "GGATECRS" .DDLReplication.currentRowid
            FROM sys.seq$ s
            WHERE s.obj# = "GGATECRS" .DDLReplication.currentObjectId;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                "GGATECRS" .DDLReplication.currentRowid := '';
            WHEN OTHERS THEN
                IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                    RAISE;
                END IF;
                "GGATECRS" .DDLReplication.currentRowid := '';
        END;
    END IF;

    IF real_ora_dict_obj_type = 'TABLE' THEN
        BEGIN
            SELECT o.obj# INTO "GGATECRS" .DDLReplication.currentObjectId
             FROM sys.obj$ o, sys.tab$ t
                WHERE ((o.obj# = "GGATECRS" .DDLReplication.ddlObjNum
                AND o.obj# = t.obj#) AND bitand(t.property, 1) IN (0, 1)); -- account for object table (value 1 for t.property bitand)
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                "GGATECRS" .DDLReplication.currentObjectId := NULL;
            WHEN OTHERS THEN
                IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                    RAISE;
                END IF;
                "GGATECRS" .DDLReplication.currentObjectId := NULL;
        END;
    END IF;

    -- CREATE INDEX is special b/c we don't know it's object id, but we have to figure out table's object id!!!
    IF real_ora_dict_obj_type = 'INDEX' AND ora_sysevent = 'CREATE'  THEN
        -- we need base object id when indexed, it affects tables with no keys (ddlrep_2)
        BEGIN

            IF  "GGATECRS" .DDLReplication.ddlBaseObjNum <> -1 THEN
              "GGATECRS" .DDLReplication.currentObjectId :=
                            "GGATECRS" .DDLReplication.ddlBaseObjNum;
              SELECT o.name, u.name into real_ora_dict_obj_name,
                                         real_ora_dict_obj_owner
              from sys.obj$ o , sys.user$ u where
              o.obj# = "GGATECRS" .DDLReplication.ddlBaseObjNum and
              u.user# = o.owner# ;
            ELSE
              "GGATECRS" .DDLReplication.getTableFromIndex (
                                                          stmt,
                                                          ora_dict_obj_owner,
                                                          ora_dict_obj_name,
                                                          real_ora_dict_obj_owner,
                                                          real_ora_dict_obj_name,
                                                          otype);
            IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'CREATE INDEX, parent: [' || otype || '] [' ||
                                            real_ora_dict_obj_owner || '.' || real_ora_dict_obj_name || ']');
            END IF;
              SELECT o.object_id
              INTO "GGATECRS" .DDLReplication.currentObjectId
              FROM dba_objects o
              WHERE o.object_type = otype
              AND o.object_name = real_ora_dict_obj_name AND
                  o.owner = real_ora_dict_obj_owner;

              "GGATECRS" .DDLReplication.ddlBaseObjNum :=
                           "GGATECRS" .DDLReplication.currentObjectId ;
            END IF;

            IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'CREATE INDEX, parent object id: ' || "GGATECRS" .DDLReplication.currentObjectId);
            END IF;

            "GGATECRS" .DDLReplication.currentMasterName := real_ora_dict_obj_name;
            "GGATECRS" .DDLReplication.currentMasterOwner := real_ora_dict_obj_owner;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                "GGATECRS" .DDLReplication.currentObjectId := NULL;
            WHEN OTHERS THEN
                IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                    RAISE;
                END IF;
                "GGATECRS" .DDLReplication.currentObjectId := NULL;
        END;
    END IF;
    IF real_ora_dict_obj_type = 'INDEX' AND ora_sysevent = 'DROP' THEN
        BEGIN
            SELECT bitand(i.property, 1)
            INTO indexUnique
            FROM sys.ind$ i
            WHERE i.obj# = "GGATECRS" .DDLReplication.ddlObjNum;

            IF indexUnique = 1 THEN
             indexUnique := 'UNIQUE';
            ELSE
             indexUnique := 'NONUNIQUE';
            END IF;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                indexUnique := 'NONUNIQUE';
            WHEN OTHERS THEN
                IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                    RAISE;
                END IF;
                indexUnique := 'NONUNIQUE';
        END;
    ELSE
        indexUnique := 'NONUNIQUE';
    END IF;
    -- for all synonyms, except for CREATE (where not available)
    -- get table owner/name so it can be used in extract
    IF real_ora_dict_obj_type = 'SYNONYM' AND ora_sysevent <> 'CREATE' THEN
        BEGIN
            SELECT s.owner, s.name
            INTO
                "GGATECRS" .DDLReplication.currentMasterOwner,
                "GGATECRS" .DDLReplication.currentMasterName
            FROM sys.syn$ s
            WHERE
                s.obj# = "GGATECRS" .DDLReplication.ddlObjNum;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
            IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'Could not find table for public synonym: ' || real_ora_dict_obj_name);
            END IF;
            -- do nothing, PUBLIC/synName is used
        END;
    END IF;

    /*

    At this point we have object id of table/sequence as well as base object owner/name
    (if object is not table)

    */


    IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [2]' );
    END IF;


    IF real_ora_dict_obj_type = 'COLUMN' AND ora_sysevent = 'COMMENT' THEN
        BEGIN
        --  here we try to obtain object id for COMMENT on COLUMN.  We get the table name
        -- because object name is always reported as tableName.columnName. Note that we
        -- cannot support quoted names that contain dots, because RDBMS reports both table
        -- and column name without quotes.  So for example table "a.g" with column "d.e" is
        -- reported as a.g.d.e, i.e. it is ambiguous.
        -- In case there is an error here, we do nothing, because this DDL can easily be
        -- ignored via DDLERROR if it's a problem (such as with global temp tables).
        SELECT obj# INTO "GGATECRS" .DDLReplication.currentObjectId
        FROM sys.obj$
        WHERE owner#= (SELECT user# FROM sys.user$ WHERE name=real_ora_dict_obj_owner)
        AND name = substr (real_ora_dict_obj_name, 1, instr (real_ora_dict_obj_name,'.') -1)
        AND type# = 2;
        EXCEPTION
            WHEN OTHERS THEN -- do nothing
            NULL;
        END;
    END IF;


    -- check if object is valid.
    -- For example, when compiling triggers, procedures, packages, object may not compile
    -- in this case DDL is still considered successful and this DDL trigger will not rollback
    -- however status of object will be INVALID
    BEGIN
        SELECT d.status, d.generated, d.temporary, d.secondary, d.object_type,
	       decode(bitand(t.property,1),1,'YES','NO'),
	       decode(bitand(t.property,8192),8192,'YES','NO'),
	       decode(bitand(t.property,4611686018427387904),4611686018427387904,'YES','NO'),
	       decode(bitand(t.property,288230376151711744),288230376151711744,'YES','NO')
        INTO objstatus, objectGenerated, objectTemporary, objectSecondary, objectType, isTypeTable, isNestedTable, isValidTimeTable, isIdentityColTable
        FROM dba_objects d, sys.tab$ t
        WHERE d.object_id = "GGATECRS" .DDLReplication.currentObjectId and t.obj# = "GGATECRS" .DDLReplication.currentObjectId;
        IF (objstatus <> 'VALID') THEN
            IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
                "GGATECRS" .trace_put_line ('DDL', 'DDL operation yielded invalid status, extract will decide if ignored. DDL operation [' ||
                                        stmt || '], object [' || real_ora_dict_obj_owner || '.' || real_ora_dict_obj_name || '], status [' ||
                                        objstatus || ']');
            END IF;
        END IF;
        IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
			"GGATECRS" .trace_put_line ('DDLTRACE1', 'Object atts/type: [gen=' || objectGenerated ||
			', temp=' || objectTemporary || ', sec=' || objectSecondary || ', type=[' || objectType ||
			'], typed table=[' || isTypeTable || '], nested table=[' || isNestedTable ||
			'], valid time=[' || isValidTimeTable || '], identity col=[' || isIdentityColTable || ']');
	END IF;
        IF (objectGenerated = 'Y' AND objectType <> 'TABLE PARTITION')
			OR objectTemporary = 'Y' OR objectSecondary = 'Y' OR isNestedTable = 'YES' OR isValidTimeTable = 'YES' OR isIdentityColTable = 'YES' THEN
            toIgnore := 'YES';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN -- do nothing because for new tables there is no entry
            IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                RAISE;
            END IF;
            NULL;
    END;

    -- ignore secondary sequence objects
    BEGIN
        IF real_ora_dict_obj_type = 'SEQUENCE' THEN
         SELECT d.generated, d.temporary, d.secondary
            INTO objectGenerated, objectTemporary, objectSecondary
            FROM dba_objects d
            WHERE d.object_id = "GGATECRS" .DDLReplication.currentObjectId;
            IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'Sequence Object atts/type: [gen=' || objectGenerated ||
                ', temp=' || objectTemporary || ', sec=' || objectSecondary || ']');
  	    END IF;
             IF objectGenerated = 'Y' OR objectTemporary = 'Y' OR objectSecondary = 'Y' THEN
               toIgnore := 'YES';
            END IF;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN -- do nothing because for new tables there is no entry
            IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                RAISE;
            END IF;
            NULL;
    END;

    IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
        "GGATECRS" .trace_put_line ('DDL',
                                'DDL operation [' || stmt || '], sequence [' || "GGATECRS" .DDLReplication.currentDDLSeq || '], '
                                || 'DDL type [' || ora_sysevent || '] ' || ora_dict_obj_type || ', real object type [' || real_ora_dict_obj_type ||
                                '], validity [' || objstatus || '], object ID [' || "GGATECRS" .DDLReplication.currentObjectId
                                || '], object [' || ora_dict_obj_owner || '.' || ora_dict_obj_name || '],'
                                || ' real object [' || real_ora_dict_obj_owner || '.' || real_ora_dict_obj_name || '],'
                                || ' base object schema [' || "GGATECRS" .DDLReplication.currentMasterOwner || '],'
                                || ' base object name [' || "GGATECRS" .DDLReplication.currentMasterName || '],'
                                || ' logged as [' || ora_login_user || ']');
    END IF;


    BEGIN
        SELECT o.dataobj#
        INTO "GGATECRS" .DDLReplication.currentDataObjectId
        FROM sys.obj$ o
        WHERE o.obj# = "GGATECRS" .DDLReplication.currentObjectId;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            "GGATECRS" .DDLReplication.currentDataObjectId := 0;
        WHEN OTHERS THEN
            IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                RAISE;
            END IF;
            "GGATECRS" .DDLReplication.currentDataObjectId := 0;
    END;


    IF real_ora_dict_obj_type = 'TABLE' and ora_sysevent <> 'CREATE'
    THEN
      "GGATECRS".DDLReplication.ddlBaseObjNum :=
                        "GGATECRS".DDLReplication.ddlObjNum;
    END IF;
    --dbms_output.put_line(ora_dict_obj_type);
    "GGATECRS".DDLReplication.getObjType(real_ora_dict_obj_type, ntype);
    --dbms_output.put_line(ntype);
    IF "GGATECRS".DDLAux.SKIP_OBJECT(
                   null,"GGATECRS".DDLReplication.ddlBaseObjNum ,
                   ora_dict_obj_name, ora_dict_obj_owner ,
                   ntype,
                   "GGATECRS" .DDLReplication.currentMasterName ,
                   "GGATECRS" .DDLReplication.currentMasterOwner ,
                   ora_sysevent)

    THEN
       "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);
       RETURN;
    END IF;

    -- these are stored in columns of DDL history table
    -- they are oracle's original just like for marker table
    -- 'real' ones are used to actually derive metadata *only*
    "GGATECRS" .DDLReplication.currentObjectName := ora_dict_obj_name;
    "GGATECRS" .DDLReplication.currentDDLType := ora_sysevent;
    "GGATECRS" .DDLReplication.currentObjectOwner := ora_dict_obj_owner;
    "GGATECRS" .DDLReplication.currentObjectType := ora_dict_obj_type;

    IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [3]' );
    END IF;

    IF real_ora_dict_obj_type = 'INDEX' AND ora_sysevent = 'CREATE' and otype = 'TABLE' THEN
    	IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        	"GGATECRS" .trace_put_line ('DDLTRACE1', 'checking create index for parent type:' || otype ||
  		' owner:' || real_ora_dict_obj_owner || ' name:' || real_ora_dict_obj_name ||
  		' object id:' || to_char("GGATECRS" .DDLReplication.currentObjectId));
	END IF;

        BEGIN
           -- test that base table object exists.
           SELECT t.obj#
           INTO "GGATECRS" .DDLReplication.currentObjectId
           FROM sys.tab$ t
           WHERE t.obj# = "GGATECRS" .DDLReplication.currentObjectId;
	   EXCEPTION
              WHEN NO_DATA_FOUND THEN BEGIN

                 -- check to see if an index on a synonym
                 -- test that base table object exists.
                 select o2.obj#
                    INTO "GGATECRS" .DDLReplication.currentObjectId
                 from sys.obj$ o1,
                      sys.user$ u1,
                      sys.syn$ s,
                      sys.user$ u2,
                      sys.obj$ o2
                 where o1.name = real_ora_dict_obj_name
                     and o1.owner# = u1.user#
                     and u1.name = real_ora_dict_obj_owner
                     and o1.type# = 5 /* synonym */
                     and o1.obj# = s.obj#
                     and s.owner = u2.name
                     and s.name = o2.name
                     and u2.user# = o2.owner#
                     and o2.type# = 2; /* table */
                 EXCEPTION
                     WHEN NO_DATA_FOUND THEN BEGIN
                         toIgnore := 'YES';
                         IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                            "GGATECRS" .trace_put_line ('DDLTRACE1', 'Base table does not exists');
                         END IF;
                 END;
           END;
       END;
    END IF;

    /*
    insert DDL descriptor string to marker table
    DDL STATEMENT and related info
    construct DDL operation descriptor string
    marker record contains original object name, whereas DDL record contains 'real' (adjusted for INDEX->TABLE)

    */

    "GGATECRS" .DDLReplication.saveMarkerDDL (
                                              to_char ("GGATECRS" .DDLReplication.currentObjectId),
                                              ora_dict_obj_owner,
                                              ora_dict_obj_name,
                                              real_ora_dict_obj_type,
                                              ora_sysevent,
                                              to_char ("GGATECRS" .DDLReplication.currentDDLSeq),
                                              'GGATECRS' || '.' || 'GGS_DDL_HIST',
                                              ora_login_user,
                                              objstatus,
                                              indexUnique,
                                              "GGATECRS" .DDLReplication.currentMasterOwner,
                                              "GGATECRS" .DDLReplication.currentMasterName,
                                              stmt,
                                              toIgnore);



    /*

    Get Start SCN
    IMPORTANT: start SCN can be obtained *only* after marker record has been
    written - this is Oracle limitation because transaction had no data so far
    (even though this is DDL transaction by itself, however in BEFORE trigger
    there is no start SCN until it's done because transaction hasn't officially
    started yet!!)

    */

    -- get current module info
    dbms_application_info.read_module(oldModuleNameInfo, oldActionInfo);
    -- 'stamp' current session with unique ddl sequence number
    -- this works even when we have multiple DDLs happenning in several background processes (all with session id of 0)
    moduleNameInfo := 'GGS_DDL_MODULE_' || to_char ("GGATECRS" .DDLReplication.currentDDLSeq);
    dbms_application_info.set_module(moduleNameInfo, null);


    -- we let potential error here be handled by extract as it should never happen that we can't find SCN
    SELECT t.start_scnb, t.start_scnw
    INTO "GGATECRS" .DDLReplication.SCNB, "GGATECRS" .DDLReplication.SCNW
    FROM v$transaction t, v$session s
    WHERE
    t.addr = s.taddr AND t.ses_addr = s.saddr AND s.audsid = USERENV('SESSIONID')
    AND s.module = moduleNameInfo;


    IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
        "GGATECRS" .trace_put_line ('DDL',
                                'Start SCN found [' || to_char("GGATECRS" .DDLReplication.SCNB + "GGATECRS" .DDLReplication.SCNW * power (2, 32)) || ']');
    END IF;

    -- restore module info
    dbms_application_info.set_module(oldModuleNameInfo, oldActionInfo);

    -- do not calculate/record any metadata for objects other than table, index or trigger
    -- because these are the objects we need to resolve base owner/name for
    -- also do not calculate metadata for TRUNCATE TABLE
    -- because customer may have hundreds of those - they don't change table structure!!!
    IF (NOT real_ora_dict_obj_type = 'TABLE' AND
        NOT real_ora_dict_obj_type = 'INDEX' AND
        NOT real_ora_dict_obj_type = 'TRIGGER' AND
        NOT real_ora_dict_obj_type = 'SEQUENCE') OR
        (real_ora_dict_obj_type = 'TABLE' AND ora_sysevent = 'TRUNCATE') OR
        (real_ora_dict_obj_type = 'TRIGGER' AND ora_sysevent <> 'CREATE')
        OR "GGATECRS" .DDLReplication.stay_metadata = 1 -- do not query db for metadata if STAYMETADATA is ON
        THEN
        IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
            "GGATECRS" .trace_put_line ('DDL', '------------------------- End of log for DDL sequence [' ||
                                to_char ("GGATECRS" .DDLReplication.currentDDLSeq) || '], no DDL history metadata recorded for this DDL operation');
        END IF;
        IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
            dbms_session.set_sql_trace(false);
        END IF;
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

        RETURN;
    END IF;



    IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        "GGATECRS" .trace_put_line ('DDL', 'Object ID  is [' || to_char ("GGATECRS" .DDLReplication.currentObjectId) ||
                                    ']');
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [4]' );
    END IF;

    -- In general, history is not required for CREATE DDLs as there can't be
    -- any DML for an object prior to it being created. This also
    -- eliminates the problem of objects that don't exist in the context
    -- of ddl trigger, since this is before ddl trigger. Any CREATE DDL
    -- suffers from that issue.
    -- For CREATE INDEX DDLs take history as the key sey may change as
    -- a result of the DDL.
    IF (ora_sysevent <> 'CREATE' OR
	(toIgnore = 'NO' AND real_ora_dict_obj_type = 'INDEX' AND otype = 'TABLE')) THEN
        "GGATECRS" .DDLReplication.beginHistory ();
        IF real_ora_dict_obj_type = 'SEQUENCE' THEN
            /*
                For sequences, we need sequence object id, name and rowid for the most part in order to map rowid to objectid/name
                As sequences don't have properties as tables, this is where we must stop gathering metadata as well
            */
            IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [4-seq], sequence cache [' ||
                                            to_char (seqCache) || '], sequence incrementby [' || to_char (seqIncrementBy) || ']' );
            END IF;

            "GGATECRS" .DDLReplication.saveSeqInfo (
                      real_ora_dict_obj_owner, real_ora_dict_obj_name,
                      ora_sysevent, to_char(currUserId),
                      seqCache, seqIncrementBy, toIgnore );
        ELSE

        /*

        BEGIN HISTORY table inserts
        begin inserting metadata to history

        */

            -- metadata producing calls
            -- IMPORTANT: here we use real_ora_ values b/c resolution depends on it, also object id is correlated
            IF "GGATECRS" .DDLReplication.trace_level >= 2 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE2', 'Goint to call getTableInfo() ' || stmt);
            END IF;


            "GGATECRS" .DDLReplication.getTableInfo (
                      "GGATECRS" .DDLReplication.ddlBaseObjNum,
                      real_ora_dict_obj_name,
                      real_ora_dict_obj_owner,
                      real_ora_dict_obj_type,
                      ora_sysevent, to_char(currUserId),
                      "GGATECRS" .DDLReplication.currentMasterOwner,
                      "GGATECRS" .DDLReplication.currentMasterName,
                      substr (stmt, 1, 4000 - 10),
                      toIgnore,
                      isTypeTable);

            "GGATECRS" .DDLReplication.getColDefs (
                        "GGATECRS".DDLReplication.ddlBaseObjNum,
                        real_ora_dict_obj_owner,
                        real_ora_dict_obj_name);

            IF "GGATECRS" .DDLReplication.useAllKeys = 1 THEN
                "GGATECRS" .DDLReplication.getKeyColsUseAllKeys (
                              "GGATECRS" .DDLReplication.ddlBaseObjNum,
                               real_ora_dict_obj_owner,
                               real_ora_dict_obj_name);
            ELSE
                "GGATECRS" .DDLReplication.getKeyCols (
                              "GGATECRS" .DDLReplication.ddlBaseObjNum,
                              real_ora_dict_obj_owner,
                              real_ora_dict_obj_name);
            END IF;

            IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [5]' );
            END IF;
            -- end inserting metadata to history

        /*

        END HISTORY table inserts

        */
        END IF;
        /* make sure endHistory record is placed for sequences too */
        "GGATECRS" .DDLReplication.endHistory ();

    END IF;
    BEGIN
      IF 'FALSE' = 'TRUE' OR 'FALSE' = 'TRUE' THEN
	  "GGATECRS" .trace_put_line ('DDLTRACE1', 'Trigger: Raising simulated 1013 error');
	  RAISE userCancelSimulate;
      END IF;
      EXCEPTION
          WHEN OTHERS THEN
            IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                RAISE;
            END IF;
            IF 'FALSE' = 'TRUE' THEN
	        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Trigger: Raising simulated nested 1013 error');
                RAISE userCancelNestedSimulate;
            ELSE
                RAISE;
            END IF;
    END;

    -- this is always after last executable statement
    IF "GGATECRS" .DDLReplication.trace_level >= 1 THEN
        "GGATECRS" .trace_put_line ('DDLTRACE1', 'Before Trigger: point in execution = [the end]' );
    END IF;


    -- EXCEPTIONS
    -- handle exceptions (if so specified)

    IF "GGATECRS" .DDLReplication.trace_level >= 0 THEN
        "GGATECRS" .trace_put_line ('DDL', '------------------------- End of log for DDL sequence [' ||
                                to_char ("GGATECRS" .DDLReplication.currentDDLSeq) || ']');
    END IF;

    IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
        dbms_session.set_sql_trace(false);
    END IF;
    "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
            RAISE;
        END IF;
        "GGATECRS" .trace_put_line ('DDL', 'Trigger sys.' || 'GGS_DDL_TRIGGER_BEFORE' || ' :Error processing DDL operation [' || stmt || '], error '
                                    || SQLERRM || ', error stack: ' || "GGATECRS" .ddlora_getErrorStack);

        -- this code will delete any previous garbage from marker data so if trigger commits, nothing is there
        -- unless we put it down here somewhere (in big trigger exception) or in size handling above
        -- this way extract doesn't abend from interrupted garbage
        -- note that this really shouldn't happen (it does when simulated) because oracle actually rollsback transaction
        IF "GGATECRS" .DDLReplication.currentMarkerSeq IS NOT NULL THEN  -- only if marker seqno set
            BEGIN
                "GGATECRS" .trace_put_line ('DDL', 'Cleaning up marker sequence [' || "GGATECRS" .DDLReplication.currentMarkerSeq || ']');
                DELETE FROM "GGATECRS" ."GGS_MARKER" WHERE seqNo = "GGATECRS" .DDLReplication.currentMarkerSeq;
                "GGATECRS" .trace_put_line ('DDL', 'Cleaned up [' || SQL%ROWCOUNT || '] rows from marker table');
            EXCEPTION
                WHEN OTHERS THEN
                    IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
                        RAISE;
                    END IF;
                    "GGATECRS" .trace_put_line ('DDL', 'Trigger sys.' || 'GGS_DDL_TRIGGER_BEFORE' || ': Error processing DDL operation [' || stmt || '], error ' || SQLERRM || ', error stack: ' || "GGATECRS" .ddlora_getErrorStack);
            END;
        END IF;
        -- we also delete DDL seqno, so it's not accidentally selected in extract if trigger had problems
		-- and thus incomplete data

		BEGIN
			"GGATECRS" .trace_put_line ('DDL', 'Cleaning up DDL sequence [' || "GGATECRS" .DDLReplication.currentDDLSeq || ']');
			DELETE FROM "GGATECRS" ."GGS_DDL_HIST" WHERE seqNo = "GGATECRS" .DDLReplication.currentDDLSeq;
			"GGATECRS" .trace_put_line ('DDL', 'Cleaned up [' || SQL%ROWCOUNT || '] rows from DDL table');
		EXCEPTION
			WHEN OTHERS THEN
				IF instr ("GGATECRS" .DDLReplication.raisable_errors, to_char (SQLCODE, 'S00000')) > 0 THEN
					RAISE;
				END IF;
				NULL; -- this is a curtesy delete, ignore if any error
		END;

		IF toIgnore = 'YES' THEN
            -- if we're somehow here, and DDL is ignored anyway, don't error out
            "GGATECRS" .trace_put_line ('DDL', 'DDL is ignored, error is ignored too.');
            IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
                dbms_session.set_sql_trace(false);
            END IF;
            "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

            RETURN;
        END IF;

        IF SQLCODE = -1013 OR "GGATECRS" .ddlora_errorIsUserCancel THEN
            -- this is user cancellation error, just  exit, never mind all this
            -- what happens is that Oracle rollsback previous INSERTs but we would have
            -- started new one here. We just want to ignore everything, hence RETURN
            "GGATECRS" .trace_put_line ('DDL', 'User cancelled operation');
            IF 'FALSE' = 'TRUE' OR 'FALSE' = 'TRUE' THEN
                "GGATECRS" .trace_put_line ('DDLTRACE1', 'forced user cancel test stack ' ||
                                             DBMS_UTILITY.format_error_stack);
            END IF;
            IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
                dbms_session.set_sql_trace(false);
            END IF;
            "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

            RETURN;
        END IF;
        IF disallowDDL = 1 THEN
            IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
                dbms_session.set_sql_trace(false);
            END IF;
            raise_application_error (-20782,
                                     "GGATECRS" .DDLReplication.triggerErrorMessage || ':' || SQLERRM ||
                                     ', error stack: ' || "GGATECRS" .ddlora_getErrorStack);
        ELSE
            /*

            if there is trouble in trigger
            try to make sure extract knows about it
            include min necessary information for end-user to examine trace log

            */


            IF SQLCODE = -6508 THEN
                -- this is improper installation, alert extract to it so user knows
                outMessage := 'INSTALLPROBLEM: Oracle could not find properly installed DDL replication package (ORA-6508). Please ' ||
                ' install or upgrade DDL replication package for Oracle (PLSQL code) before proceeding. Please make sure all ' ||
                'processes that use DDL are shutdown during trigger installation. The actual DDL here may or may not succeed.';
                INSERT INTO "GGATECRS" ."GGS_MARKER" (
                    seqNo,
                    fragmentNo,
                    optime,
                    TYPE,
                    SUBTYPE,
                    marker_text
                )
                VALUES (
                    -1,
                    0,
                    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
                    'DDL',
                    'DDLINFO',
                     outMessage -- text of marker
                );
            ELSE
                IF "GGATECRS" .DDLReplication.currentMarkerSeq  IS NULL THEN  -- only if marker seqno not set
                    SELECT "GGATECRS" ."GGS_MARKER_SEQ" .NEXTVAL INTO "GGATECRS" .DDLReplication.currentMarkerSeq FROM dual;
                END IF;
                outMessage := 'ERROR: DDL sequence [' || to_char ("GGATECRS" .DDLReplication.currentDDLSeq) ||
                '], marker sequence [' || to_char ("GGATECRS" .DDLReplication.currentMarkerSeq) ||
                '], DDL trace log file [' || "GGATECRS" .DDLReplication.dumpDir || "GGATECRS" .file_separator || 'ggs_ddl_trace.log], error code ' ||
                to_char(SQLCODE) || ' error message ' || SQLERRM || ', error stack: ' || "GGATECRS" .ddlora_getErrorStack;
                INSERT INTO "GGATECRS" ."GGS_MARKER" (
                    seqNo,
                    fragmentNo,
                    optime,
                    TYPE,
                    SUBTYPE,
                    marker_text
                )
                VALUES (
                    "GGATECRS" .DDLReplication.currentMarkerSeq,
                    0,
                    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
                    'DDL',
                    'DDLINFO',
                         outMessage -- text of marker
                );
            END IF;
            IF 'FALSE' = 'TRUE' OR instr(outMessage,'error code -1089') > 0 THEN
                IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
                    dbms_session.set_sql_trace(false);
                END IF;
                raise_application_error (-20782,
                                         "GGATECRS" .DDLReplication.triggerErrorMessage || ':' || SQLERRM);
            END IF;
        END IF;
        IF "GGATECRS" .DDLReplication.sql_trace = 1 THEN
            dbms_session.set_sql_trace(false);
        END IF;
        "GGATECRS" .DDLReplication.setCtxInfo(-1,-1,-1,-1,-1);

END;