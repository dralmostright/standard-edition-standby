from dbaconsole import db

class Cdbtempalte(db.Model):
    cdb_tid = db.Column(db.Integer, primary_key=True)
    cdb_ttype= db.Column(db.String(120), nullable=True)
    cdb_tname= db.Column(db.String(60), nullable=False)
    cdb_tpname= db.Column(db.String(120), nullable=False)
    cdb_tpvalue = db.Column(db.String(120), nullable=False)