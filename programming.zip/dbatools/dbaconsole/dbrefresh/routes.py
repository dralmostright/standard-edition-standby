from flask import render_template, Blueprint, flash, redirect, url_for
from flask_login import login_user, current_user, logout_user
from dbaconsole.dbrefresh.forms import CloneDBTeamplate;
from dbaconsole import db
from dbaconsole.dbrefresh.models import Cdbtempalte
from dbaconsole.dbrefresh.utils import SplitValues

dbrefresh = Blueprint('dbrefresh', __name__)

@dbrefresh.route("/addconfig", methods=['GET','POST'])
def addconfig():
        if current_user.is_authenticated:
                return render_template('dbrefresh/addconfig.html', status='dbr-active')
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listrdbs", methods=['GET','POST'])
def listrdbs():
        if current_user.is_authenticated:
                return render_template('dbrefresh/listrefdbs.html', status='dbr-list')
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/addvdbtem", methods=['GET','POST'])
def addvdbtem():
        if current_user.is_authenticated:
                form=CloneDBTeamplate()
                demoparams = Cdbtempalte.query.filter_by(cdb_tname='CDB_DEMO')
                if form.validate_on_submit():
                                flash(f'{form.cdb_tname.data} Account has been Created! Please login','success')
                                parameters=SplitValues(form.cdb_parameter.data)
                                for x in range(len(parameters)):
                                        params=Cdbtempalte(cdb_ttype=form.cdb_ttype.data, 
                                                         cdb_tname=form.cdb_tname.data,
                                                         cdb_tpname=parameters[x-1][0],
                                                         cdb_tpvalue=parameters[x-1][0])
                                        db.session.add(params)
                                        db.session.commit()
                                return render_template('dbrefresh/addvdbtemp.html', form=form, status='dbr-addtp',demoparams=demoparams)
                else:
                        return render_template('dbrefresh/addvdbtemp.html',form=form, status='dbr-addtp',demoparams=demoparams)         
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listvdbtem", methods=['GET','POST'])
def listvdbtem():
        if current_user.is_authenticated:
                cdbtemplates = db.session.query(Cdbtempalte.cdb_tname).distinct().all()
                return render_template('dbrefresh/listvdbtemp.html', status='dbr-listtp',cdbtemplates=cdbtemplates)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))              
