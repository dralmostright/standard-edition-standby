from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError
from dbaconsole.dbrefresh.models import Cdbtempalte

class SourceDB(FlaskForm):
    pass

class DestServer(FlaskForm):
    pass

class CloneDBTeamplate(FlaskForm):
    cdb_ttype = StringField('Database Type', validators=[DataRequired()])
    cdb_tname = StringField('Clone Database Template Name', validators=[DataRequired(),Length(min=4)])
    cdb_parameter = TextAreaField('Database Initializtion Parameters', validators=[DataRequired()])
    cdb_submit = SubmitField('Save Template')

    def validate_cdb_tname(self, cdb_tname):
        templatename = Cdbtempalte.query.filter_by(cdb_tname=cdb_tname.data).first()
        print(templatename)
        if templatename:
            raise ValidationError('A template with template name '+cdb_tname.data+' already exists. Please try with new name.')

