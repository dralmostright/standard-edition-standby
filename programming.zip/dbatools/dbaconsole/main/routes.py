from flask import render_template, Blueprint, flash, redirect, url_for
from flask_login import login_required, current_user

main = Blueprint('main',__name__)

@login_required
@main.route("/")
@main.route("/home")
def home():
    if current_user.is_authenticated:
        return render_template('main/index.html',status='dbdash')
    else:
        flash('Your must login to access request page!','info')
        return redirect(url_for('users.login'))

@main.route("/test")
def test():
    if current_user.is_authenticated:
        return render_template('home.html',status='dbdash')
    else:
        flash('Your must login to access request page!','info')
        return redirect(url_for('users.login'))