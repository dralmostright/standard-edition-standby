// -------multilevel-accordian-menu---------
$(document).ready(function() {
  $("#accordian a").click(function() {
      var link = $(this);
      var closest_ul = link.closest("ul");
      var parallel_active_links = closest_ul.find(".active")
      var closest_li = link.closest("li");
      var link_status = closest_li.hasClass("active");
      var count = 0;

      closest_ul.find("ul").slideUp(function() {
          if (++count == closest_ul.find("ul").length){
              parallel_active_links.removeClass("active");
              parallel_active_links.children("ul").removeClass("show-dropdown");
          }
      });

      if (!link_status) {
          closest_li.children("ul").slideDown().addClass("show-dropdown");
          closest_li.parent().parent("li.active").find('ul').find("li.active").removeClass("active");
          link.parent().addClass("active");
      }
  })
});

$(document).ready(function(){
    
  var current_fs, next_fs, previous_fs; //fieldsets
  var opacity;
  
  $(".btn-next").click(function(){
      
      current_fs = $(this).parent().parent().parent().parent();
      next_fs = $(this).parent().parent().parent().parent().next();
      console.log(next_fs)
      
      //Add Class Active
      $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
      
      //show the next fieldset
      next_fs.show(); 
      //hide the current fieldset with style
      current_fs.animate({opacity: 0}, {
          step: function(now) {
              // for making fielset appear animation
              opacity = 1 - now;
  
              current_fs.css({
                  'display': 'none',
                  'position': 'relative'
              });
              next_fs.css({'opacity': opacity});
          }, 
          duration: 600
      });
  });
  
$(".btn-prev").click(function(){
  
    current_fs = $(this).parent().parent().parent().parent();
    previous_fs = $(this).parent().parent().parent().parent().prev();  
      
      //Remove class active
      $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
      
      //show the previous fieldset
      previous_fs.show();
  
      //hide the current fieldset with style
      current_fs.animate({opacity: 0}, {
          step: function(now) {
              // for making fielset appear animation
              opacity = 1 - now;
  
              current_fs.css({
                  'display': 'none',
                  'position': 'relative'
              });
              previous_fs.css({'opacity': opacity});
          }, 
          duration: 600
      });
  });
  
  $('.radio-group .radio').click(function(){
      $(this).parent().find('.radio').removeClass('selected');
      $(this).addClass('selected');
  });
  
  $(".submit").click(function(){
      return false;
  })
      
  });




  $(document).ready(function(){
    
    var current_fs, next_fs, previous_fs; //fieldsets
    var opacity;
    
    $(".next").click(function(){
        
        current_fs = $(this).parent();
        next_fs = $(this).parent().next();
        
        //Add Class Active
        $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
        
        //show the next fieldset
        next_fs.show(); 
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function(now) {
                // for making fielset appear animation
                opacity = 1 - now;
    
                current_fs.css({
                    'display': 'none',
                    'position': 'relative'
                });
                next_fs.css({'opacity': opacity});
            }, 
            duration: 600
        });
    });
    
    $(".previous").click(function(){
        
        current_fs = $(this).parent();
        previous_fs = $(this).parent().prev();
        
        //Remove class active
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
        
        //show the previous fieldset
        previous_fs.show();
    
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function(now) {
                // for making fielset appear animation
                opacity = 1 - now;
    
                current_fs.css({
                    'display': 'none',
                    'position': 'relative'
                });
                previous_fs.css({'opacity': opacity});
            }, 
            duration: 600
        });
    });
    
    $('.radio-group .radio').click(function(){
        $(this).parent().find('.radio').removeClass('selected');
        $(this).addClass('selected');
    });
    
    $(".submit").click(function(){
        return false;
    })
        
    });


    /*
    Function for handling tags
    */
    const ul = document.querySelector(".tag-box ul"),
    input = document.querySelector(".taggroup input");

    let tags = [];

    function createTag(){
        ul.querySelectorAll("li").forEach(li => li.remove());
        tags.slice().reverse().forEach(
            tag => {
                let liTag = `<li> ${tag} <i class="fa fa-fw" aria-hidden="true" onclick="removeTag(this, '${tag}')">&#xf00d</i></li>`;
                ul.insertAdjacentHTML("afterbegin", liTag);
            });
    }

    function removeTag(element, tag){
        let index = tags.indexOf(tag);
        tags = [...tags.slice(0,index), ...tags.slice(index +1)];
        element.parentElement.remove();
    }

    function addTag(e){
        if(e.keyCode == 32){
            let tag = e.target.value.replace(/\s+/g, ' ');
            if(tag.length > 1 && !tags.includes(tag)){
                 tag.split(',').forEach(tag =>{
                    tags.push (tag);
                    createTag(); 
                });
            }
            e.target.value = "";
        }
    }

//input.addEventListener("keyup", addTag)



//
// Function handling parameters

let paramsName = [];
let paramsvalue = [];

$(document).ready(function() {
    $(".tableparam a").click(function() {
        var link = $(this);
        tab_status=link.closest("li").hasClass("active");
        if(!tab_status){
            var head_panel = link.closest(".panel-heading");
            var body_panel = head_panel.siblings('.panel-body');
            var tab_panel = body_panel.children().children().eq(0);
            var txt_panel = body_panel.children().children().eq(1);
            var tablines = txt_panel.children('textarea').val().split('\n');
            tab_panel.children().children().children().eq(1).children('tr').remove();
            var tabletr;
            var values;
            paramsName = [];
            paramsvalue = [];
            $.each(tablines, function(){
                values = this.split('=');
                if (values.length > 1 ) {
                    paramsName.push(values[0]);
                    paramsvalue.push(values[1]);
                    tabletr=`<tr><td>${values[0]}</td><td>${values[1]}</td>`;
                    tab_panel.children().children().children().eq(1).append(tabletr);
                }
            });
        }
    })
  });

//
// Function handling parameters
$(document).ready(function() {
    $(".textparam a").click(function() {
        var link = $(this);
        tab_status=link.closest("li").hasClass("active");
        if(!tab_status){
            var head_panel = link.closest(".panel-heading");
            var body_panel = head_panel.siblings('.panel-body');
            var tab_panel = body_panel.children().children().eq(0);
            var table_panel = tab_panel.children().children().children().eq(1).children('tr').children('td');
            //var table_panel = tab_panel.children().children().children().eq(1).children('tr').children('td:not(:last-child)');
            var txt_panel = body_panel.children().children().eq(1);
            var lengthPrm=table_panel.length;
            var textValue= "";
            for (let i = 0; i < lengthPrm; i++) {
                if (i%2 == 0 ){
                    paramsName.push(table_panel.eq(i).text());
                    textValue +=table_panel.eq(i).text()+'=';
                }
                else {
                    paramsvalue.push(table_panel.eq(i).text());
                    textValue +=table_panel.eq(i).text()+'\r\n';
                }
              }
              txt_panel.children('textarea').val(textValue); 
        }
    })
  });


$(document).ready(function() {
    var link = $(".textparam a");
    tab_status=link.closest("li").hasClass("active");
    if(!tab_status){
        var head_panel = link.closest(".panel-heading");
        var body_panel = head_panel.siblings('.panel-body');
        var tab_panel = body_panel.children().children().eq(0);
        var table_panel = tab_panel.children().children().children().eq(1).children('tr').children('td');
        //var table_panel = tab_panel.children().children().children().eq(1).children('tr').children('td:not(:last-child)');
        var txt_panel = body_panel.children().children().eq(1);
        var lengthPrm=table_panel.length;
        var textValue= "";
        for (let i = 0; i < lengthPrm; i++) {
            if (i%2 == 0 ){
                paramsName.push(table_panel.eq(i).text());
                textValue +=table_panel.eq(i).text()+'=';
            }
            else {
                paramsvalue.push(table_panel.eq(i).text());
                textValue +=table_panel.eq(i).text()+'\r\n';
            }
            }
            txt_panel.children('textarea').val(textValue); 
    }
});


function pagTable(){
    
}


function paginate(totalPages, page){
let liTag = '';
let activeLi;
let beforePages = page -1;
let afterPages = page + 1;
let pagelength;

if (page > 1){
    liTag+=`<li class="numb" onclick="paginate(totalPages, ${page -1})"><span><i class="fa fa-angle-left">&nbsp;Previous</i></span></li>`
}

if (page > 2){
    liTag +=`<li class="numb" onclick="paginate(totalPages, 1)"><span>1</span></li>`;
    if (page > 3){
        liTag +=`<li class="dots"><span>...</span></li>`
    }
}

for (pagelength= beforePages; pagelength <= afterPages; pagelength++) {  
    if (pagelength > totalPages){
        continue;
    }
    if (pagelength == 0){
        liTag+=`<li class="disabled"><span><i class="fa fa-angle-left">&nbsp;Previous</i></span></li>`;
        pagelength = pagelength +1;
    }

    if(page == pagelength){
        activeLi="active";
    }
    else {
        activeLi="";
    }
    liTag+=`<li class="numb ${activeLi}" onclick="paginate(totalPages, ${pagelength})"><span>${pagelength}</span></li>`
} 

if (page < totalPages -1){
    if (page < totalPages -2){
        liTag +=`<li class="dots"><span>...</span></li>`
    }
    liTag +=`<li class="numb" onclick="paginate(totalPages, ${totalPages})"><span>${totalPages}</span></li>`;
}
if (page < totalPages) {
    liTag+=`<li onclick="paginate(totalPages, ${page+1})"><span>Next&nbsp;<i class="fa fa-angle-right"></i></span></li>`;
}

if (page == totalPages) {
    liTag+=`<li class="disabled"><span>Next&nbsp;<i class="fa fa-angle-right"></i></span></li>`;
}

ulTag.innerHTML=liTag;
}

paginate (totalPages, 1);