from msilib.schema import Class
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError

class SourceDB(FlaskForm):
    pass

class DestServer(FlaskForm):
    pass
