from dbaconsole import dbaapp
app=dbaapp()
from dbaconsole import db
with app.app_context():
    db.drop_all()
    db.create_all()