import os

class Config:
    SECRET_KEY = 'ABCDEF'
    #SECRET_KEY = os.environ.get('SECRET_KEY')
    # for sqlite
    SQLALCHEMY_DATABASE_URI = 'sqlite:///../dbatoos.db'
    ##SQLALCHEMY_DATABASE_URI = 'mysql://root:mysql@localhost/dbatools'
    #SQLALCHEMY_DATABASE_URI = os.environ.get('SQLALCHEMY_DATABASE_URI')
    MAIL_SERVER = 'smtp.googlemail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('EMAIL_USER')
    MAIL_PASSWORD = os.environ.get('EMAIL_PASS')