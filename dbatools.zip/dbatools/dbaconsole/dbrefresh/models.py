from dbaconsole import db

class Cdbtempalte(db.Model):
    cdb_tid = db.Column(db.Integer, primary_key=True)
    cdb_ttype= db.Column(db.String(120), nullable=True)
    cdb_tname= db.Column(db.String(60), nullable=False)
    cdb_tpname= db.Column(db.String(120), nullable=False)
    cdb_tpvalue = db.Column(db.String(120), nullable=False)

class CDBSRCDB(db.Model):
    cdb_src_mstrname = db.Column(db.String(60), primary_key=True)
    cdb_src_dbname = db.Column(db.String(60), nullable=False)
    cdb_src_dbuname = db.Column(db.String(60), nullable=False)
    cdb_src_dbhost = db.Column(db.String(60), nullable=False)
    cdb_src_dbport = db.Column(db.String(5), nullable=False)
    cdb_src_dbservice = db.Column(db.String(60), nullable=False)
    cdb_src_zfsmount = db.Column(db.String(60), nullable=False)
    cdb_src_dbuser = db.Column(db.String(60), nullable=False)
    cdb_src_dbusrpwd = db.Column(db.String(60), nullable=False)

class CDBZFSSRV(db.Model):
    cdb_zfs_id = db.Column(db.Integer, primary_key=True)
    cdb_zfs_name = db.Column(db.String(60), nullable=False)
    cdb_zfs_host = db.Column(db.String(60), nullable=False)
    cdb_zfs_user = db.Column(db.String(60), nullable=False)
    cdb_zfs_password = db.Column(db.String(5), nullable=False)

class CDBTARGETDB(db.Model):
    cdb_tar_id = db.Column(db.Integer, primary_key=True)
    cdb_tar_dbname = db.Column(db.String(60), nullable=False)
    cdb_tar_dbuname = db.Column(db.String(60), nullable=False)
    cdb_tar_dbhost = db.Column(db.String(60), nullable=False)
    cdb_tar_dbport = db.Column(db.String(5), nullable=False)
    cdb_tar_dbservice = db.Column(db.String(60), nullable=False)
    cdb_tar_mount = db.Column(db.String(60), nullable=False)
