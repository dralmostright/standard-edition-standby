from flask import render_template, Blueprint, flash, redirect, url_for, abort, request
from flask_login import login_user, current_user, logout_user
from dbaconsole.dbrefresh.forms import CloneDBTeamplate,CloneEditDBTeamplate,\
                                CloneADDConfig,CloneADDZFSConfig,CloneEditZFSConfig
from dbaconsole import db
from dbaconsole.dbrefresh.models import Cdbtempalte, CDBSRCDB, CDBZFSSRV
from dbaconsole.dbrefresh.utils import SplitValues

dbrefresh = Blueprint('dbrefresh', __name__)

@dbrefresh.route("/addconfig", methods=['GET','POST'])
def addconfig():
        if current_user.is_authenticated:
                form = CloneADDConfig()
                if form.validate_on_submit():
                        srcdb = CDBSRCDB(
                                cdb_src_mstrname= form.cdb_src_mstrname.data,
                                cdb_src_dbname = form.cdb_src_dbname.data,
                                cdb_src_dbuname = form.cdb_src_dbuname.data,
                                cdb_src_dbhost = form.cdb_src_dbhost.data,
                                cdb_src_dbport = form.cdb_src_dbport.data,
                                cdb_src_dbservice = form.cdb_src_dbservice.data,
                                cdb_src_zfsmount = form.cdb_src_zfsmount.data,
                                cdb_src_dbuser = form.cdb_src_dbuser.data,
                                cdb_src_dbusrpwd = form.cdb_src_dbusrpwd.data
                        )
                        db.session.add(srcdb)
                        db.session.commit()
                return render_template('dbrefresh/addconfig.html', status='dbr-active', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listrdbs", methods=['GET','POST'])
def listrdbs():
        if current_user.is_authenticated:
                return render_template('dbrefresh/listrefdbs.html', status='dbr-list')
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/addvdbtem", methods=['GET','POST'])
def addvdbtem():
        if current_user.is_authenticated:
                form=CloneDBTeamplate()
                demoparams = Cdbtempalte.query.filter_by(cdb_tname='CDB_DEMO')
                if form.validate_on_submit():
                                flash(f'{form.cdb_tname.data} Init. Parameters Template has been Successfully created.','success')
                                parameters=SplitValues(form.cdb_parameter.data)
                                for x in range(len(parameters)):
                                        params=Cdbtempalte(cdb_ttype=form.cdb_ttype.data, 
                                                         cdb_tname=form.cdb_tname.data,
                                                         cdb_tpname=parameters[x-1][0],
                                                         cdb_tpvalue=parameters[x-1][1])
                                        db.session.add(params)
                                        db.session.commit()
                                return redirect(url_for('dbrefresh.editvdbtem', vdbtemplate=form.cdb_tname.data))
                else:
                        return render_template('dbrefresh/addvdbtemp.html',form=form, status='dbr-addtp',demoparams=demoparams)         
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listvdbtem", methods=['GET','POST'])
def listvdbtem():
        if current_user.is_authenticated:
                cdbtemplates = db.session.query(Cdbtempalte.cdb_tname).filter(Cdbtempalte.cdb_tname != 'CDB_DEMO').distinct().all()
                return render_template('dbrefresh/listvdbtemp.html', status='dbr-listtp',cdbtemplates=cdbtemplates)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))  

@dbrefresh.route("/editvdbtem/<string:vdbtemplate>",methods=['GET','POST'])
def editvdbtem(vdbtemplate):
        if current_user.is_authenticated:
                form=CloneEditDBTeamplate()
                demoparam = Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).first()
                if not demoparam:
                        abort(404)   
                demoparams = Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate) 
                form.cdb_tname.data=vdbtemplate;
                if form.validate_on_submit():
                        flash(f'{form.cdb_tname.data} Init. Parameters Template has been updated Successfully','success')
                        Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).delete()
                        db.session.commit()
                        parameters=SplitValues(form.cdb_parameter.data)
                        for x in range(len(parameters)):
                                if(len(parameters[x-1][0])> 0 and len(parameters[x-1][1]) > 0 ):
                                        params=Cdbtempalte(cdb_ttype=form.cdb_ttype.data, 
                                        cdb_tname=vdbtemplate,
                                        cdb_tpname=parameters[x-1][0],
                                        cdb_tpvalue=parameters[x-1][1])
                                        db.session.add(params)
                                        db.session.commit()
                        return redirect(url_for('dbrefresh.listvdbtem'))
                else:
                        return render_template('dbrefresh/editvdbtemp.html', form=form, status='dbr-edittp',demoparams=demoparams,demoparam=demoparam) 
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))  

@dbrefresh.route("/deletevdbtem/<string:vdbtemplate>",methods=['GET','POST'])
def deletevdbtem(vdbtemplate):
    if current_user.is_authenticated:
                demoparam = Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).first()
                if not demoparam:
                        abort(404) 
                Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).delete()
                db.session.commit()
                flash(f'{vdbtemplate} Init. Parameters Template has been deleted Successfully.','success')
                return redirect(url_for('dbrefresh.listvdbtem'))
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))    

@dbrefresh.route("/addzfssrv", methods=['GET','POST'])
def addzfssrv():
        if current_user.is_authenticated:
                form = CloneADDZFSConfig()
                if form.validate_on_submit():
                        zfs = CDBZFSSRV(
                                cdb_zfs_name= form.cdb_zfs_name.data,
                                cdb_zfs_host = form.cdb_zfs_host.data,
                                cdb_zfs_user = form.cdb_zfs_user.data,
                                cdb_zfs_password = form.cdb_zfs_password.data
                        )
                        db.session.add(zfs)
                        db.session.commit()
                        flash(f'{form.cdb_zfs_name.data} ZFS server details have saved successfully.','success')
                return render_template('dbrefresh/addzfssrv.html', status='dbr-addzfs', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listzfssrv", methods=['GET','POST'])
def listzfssrv():
        if current_user.is_authenticated:
                zfssrvs = CDBZFSSRV.query.all()
                return render_template('dbrefresh/listzfssrv.html', status='dbr-listzfs',zfssrvs=zfssrvs)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login')) 

@dbrefresh.route("/deletezfssrv/<int:cdb_zfs_id>",methods=['GET','POST'])
def deletezfssrv(cdb_zfs_id):
    if current_user.is_authenticated:
                demoparam = CDBZFSSRV.query.get_or_404(cdb_zfs_id)
                if demoparam:
                        CDBZFSSRV.query.filter_by(cdb_zfs_id=cdb_zfs_id).delete()
                        db.session.commit()
                        flash(f'{demoparam.cdb_zfs_name} ZFS Server details has been deleted Successfully.','success')
                        return redirect(url_for('dbrefresh.listzfssrv'))
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

@dbrefresh.route("/editzfssrv/<int:cdb_zfs_id>",methods=['GET','POST'])
def editzfssrv(cdb_zfs_id):
    if current_user.is_authenticated:
                zfssrv = CDBZFSSRV.query.get_or_404(cdb_zfs_id)
                form=CloneEditZFSConfig()
                if zfssrv:
                        if form.validate_on_submit:
                                flash(f'{cdb_zfs_id} ZFS Server details has been deleted Successfully.','success')
                                return render_template('dbrefresh/editzfssrv.html', form=form, status='dbr-edittp',zfssrv=zfssrv)
                                return redirect(url_for('dbrefresh.listzfssrv'))
                        else:
                                return render_template('dbrefresh/editzfssrv.html', form=form, status='dbr-edittp',zfssrv=zfssrv) 
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  



@dbrefresh.route("/addzfssrvd", methods=['GET','POST'])
def addconfigdd():
        if current_user.is_authenticated:
                form = CloneADDConfig()
                if form.validate_on_submit():
                        srcdb = CDBSRCDB(
                                cdb_src_mstrname= form.cdb_src_mstrname.data,
                                cdb_src_dbname = form.cdb_src_dbname.data,
                                cdb_src_dbuname = form.cdb_src_dbuname.data,
                                cdb_src_dbhost = form.cdb_src_dbhost.data,
                                cdb_src_dbport = form.cdb_src_dbport.data,
                                cdb_src_dbservice = form.cdb_src_dbservice.data,
                                cdb_src_zfsmount = form.cdb_src_zfsmount.data,
                                cdb_src_dbuser = form.cdb_src_dbuser.data,
                                cdb_src_dbusrpwd = form.cdb_src_dbusrpwd.data
                        )
                        db.session.add(srcdb)
                        db.session.commit()
                return render_template('dbrefresh/addconfig.html', status='dbr-active', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))