from flask import render_template, Blueprint, flash, redirect, url_for
from flask_login import login_user, current_user, logout_user

dbrefresh = Blueprint('dbrefresh', __name__)

@dbrefresh.route("/addconfig", methods=['GET','POST'])
def addconfig():
        return render_template('dbrefresh/addconfig.html') 