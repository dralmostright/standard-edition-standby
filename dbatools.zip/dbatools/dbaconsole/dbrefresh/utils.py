def SplitValues (text):
    values = []
    textsplit = text.strip().split('\n')
    for txt in textsplit:
        val=txt.rstrip().split('=')
        values.append(val)
    return values
