from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, PasswordField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError
from dbaconsole.dbrefresh.models import Cdbtempalte,CDBSRCDB,CDBZFSSRV

class SourceDB(FlaskForm):
    pass

class DestServer(FlaskForm):
    pass

class CloneDBTeamplate(FlaskForm):
    cdb_ttype = StringField('Database Type', validators=[DataRequired()])
    cdb_tname = StringField('Clone Database Template Name', validators=[DataRequired(),Length(min=4)])
    cdb_parameter = TextAreaField('Database Initializtion Parameters', validators=[DataRequired()])
    cdb_submit = SubmitField('Save Template')

    def validate_cdb_tname(self, cdb_tname):
        templatename = Cdbtempalte.query.filter_by(cdb_tname=cdb_tname.data).first()
        if templatename:
            raise ValidationError('A template with template name '+cdb_tname.data+' already exists. Please try with new name.')

class CloneEditDBTeamplate(FlaskForm):
    cdb_ttype = StringField('Database Type', validators=[DataRequired()])
    cdb_tname = StringField('Clone Database Template Name', validators=[DataRequired(),Length(min=4)])
    cdb_parameter = TextAreaField('Database Initializtion Parameters', validators=[DataRequired()])
    cdb_submit = SubmitField('Update Template')

class CloneADDConfig(FlaskForm):
    cdb_src_mstrname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbhost = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbport = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbservice = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsmount = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuser = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbusrpwd = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_project = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_pool = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_share = StringField('Clone Database Template Name', validators=[DataRequired()])

    def validate_cdb_src_mstrname(self, cdb_src_mstrname):
        cdbsrcdb = CDBSRCDB.query.filter_by(cdb_src_mstrname=cdb_src_mstrname.data).first()
        if cdbsrcdb:
            raise ValidationError('Configuration name '+cdb_src_mstrname.data+' already exists. Please try with new name.')

class CloneADDZFSConfig(FlaskForm):
    cdb_zfs_name = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_host = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_user = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_password = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_submit = SubmitField('Save Configuration')

    def validate_cdb_zfs_name(self, cdb_zfs_name):
        cdbsrcdb = CDBZFSSRV.query.filter_by(cdb_zfs_name=cdb_zfs_name.data).first()
        if cdbsrcdb:
            raise ValidationError('Configuration name '+cdb_zfs_name.data+' already exists. Please try with new name.')

class CloneEditZFSConfig(FlaskForm):
    cdb_zfs_name = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_host = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_user = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_password = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_submit = SubmitField('Save Configuration')

    def validate_cdb_zfs_name(self, cdb_zfs_name):
        cdbsrcdb = CDBZFSSRV.query.filter_by(cdb_zfs_name=cdb_zfs_name.data).first()
        if cdbsrcdb:
            raise ValidationError('Configuration name '+cdb_zfs_name.data+' already exists. Please try with new name.')



